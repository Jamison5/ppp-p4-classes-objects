try:
    from . import script
except ModuleNotFoundError:
    pass
