from PyInstaller.utils.hooks import get_hook_config

